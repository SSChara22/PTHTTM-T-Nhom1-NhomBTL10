<?php echo e($slot); ?>

<?php /**PATH C:\Users\Prajwal\Desktop\Advance-Ecommerce-in-laravel-7\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>