
<?php $__env->startSection('main-content'); ?>
<div class="card">
  <h5 class="card-header">Tin nhắn</h5>
  <div class="card-body">
    <?php if($message): ?>
        <?php if($message->photo): ?>
        <img src="<?php echo e($message->photo); ?>" class="rounded-circle " style="margin-left:44%;">
        <?php else: ?> 
        <img src="<?php echo e(asset('backend/img/avatar.png')); ?>" class="rounded-circle " style="margin-left:44%;">
        <?php endif; ?>
        <div class="py-4">Từ: <br>
           Tên :<?php echo e($message->name); ?><br>
           Email :<?php echo e($message->email); ?><br>
           Số điện thoại :<?php echo e($message->phone); ?>

        </div>
        <hr/>
  <h5 class="text-center" style="text-decoration:underline"><strong>Chủ đề :</strong> <?php echo e($message->subject); ?></h5>
        <p class="py-5"><?php echo e($message->message); ?></p>

    <?php endif; ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMDT\resources\views/backend/message/show.blade.php ENDPATH**/ ?>